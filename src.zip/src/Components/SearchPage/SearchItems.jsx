import React from "react";

function SearchItems() {
  return <div>SearchItems</div>;
}

export default SearchItems;

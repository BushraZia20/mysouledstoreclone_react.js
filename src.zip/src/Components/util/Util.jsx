export const token = localStorage.getItem("JWT_token");
export const projectId = "kfdh4hevj36w";
